document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginBtn').addEventListener('click', function() {
        window.location.href = 'login.html';
    });

    document.getElementById('signupBtn').addEventListener('click', function() {
        window.location.href = 'signup.html';
    });
});
