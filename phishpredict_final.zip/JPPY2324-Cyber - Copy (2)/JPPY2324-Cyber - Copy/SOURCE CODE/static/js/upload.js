document.addEventListener("DOMContentLoaded", function () {
    document.querySelector("form").onsubmit = function (event) {
        let fileInput = document.querySelector("input[type='file']");
        if (fileInput.files.length === 0) {
            alert("Please select a CSV file before uploading.");
            event.preventDefault();
        }
    };
});
