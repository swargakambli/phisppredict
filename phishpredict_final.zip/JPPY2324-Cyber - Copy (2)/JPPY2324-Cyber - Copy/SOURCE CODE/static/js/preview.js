document.addEventListener("DOMContentLoaded", function () {
    let rows = document.querySelectorAll("table tr");
    rows.forEach(row => {
        row.addEventListener("mouseover", function () {
            this.style.backgroundColor = "#f0f0f0";
        });
        row.addEventListener("mouseout", function () {
            this.style.backgroundColor = "";
        });
    });
});
