// script_signup.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-database.js";

// Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyA8cPDzcSvjvLdVdeoVFqmJjrksLJIZ12Y",
    authDomain: "phishingdb-942b2.firebaseapp.com",
    projectId: "phishingdb-942b2",
    storageBucket: "phishingdb-942b2.firebasestorage.app",
    messagingSenderId: "752083508136",
    appId: "1:752083508136:web:533f0289f9384d21275b9d"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

window.handleSignup = function () {
    const profile = document.getElementById("profile").value;
    const email = document.getElementById("email").value.trim();
    const userId = document.getElementById("userId").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (!email || !userId || !password || !confirmPassword) {
        alert("Please fill in all fields.");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    const safeUserId = userId.replace(/[.#$[\]]/g, "_");

    set(ref(db, 'signupdb/' + safeUserId), {
        profile: profile,
        email: email,
        userId: userId,
        password: password
    })
    .then(() => {
        alert("Signup successful! Redirecting...");
        if (profile === "admin") {
            window.location.href = "/admin";
        } else if (profile === "super_admin") {
            window.location.href = "/superadmin";
        } else {
            window.location.href = "/";
        }
    })
    .catch((error) => {
        console.error("Firebase Error:", error);
        alert("Error during signup. Try again.");
    });
};
