document.addEventListener("DOMContentLoaded", function () {
    // Logout Button Functionality
    const logoutBtn = document.querySelector(".logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function () {
            alert("Logging out...");
            window.location.href = "login.html"; // Redirect to login page
        });
    }

    // Button Animations
    const buttons = document.querySelectorAll(".btn");
    buttons.forEach(button => {
        button.addEventListener("mouseover", function () {
            this.style.transform = "scale(1.1)";
        });

        button.addEventListener("mouseout", function () {
            this.style.transform = "scale(1)";
        });

        button.addEventListener("click", function () {
            this.style.backgroundColor = "#ff3b3b";
            setTimeout(() => {
                this.style.backgroundColor = "#E15959";
            }, 300);
        });
    });

    // Manage Admins Button Functionality
    const manageAdminsBtn = document.querySelector("#manage-admins");
    if (manageAdminsBtn) {
        manageAdminsBtn.addEventListener("click", function () {
            alert("Opening admin management panel...");
            // Future functionality can be added here
        });
    }
});
